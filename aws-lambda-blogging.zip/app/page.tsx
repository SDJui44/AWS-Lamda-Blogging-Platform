import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold tracking-tight mb-4">Lambda Blog Platform</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          A serverless blogging platform built with AWS Lambda, API Gateway, DynamoDB, S3, CloudFront, and SES
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle>Serverless Architecture</CardTitle>
            <CardDescription>Run without any inflexible hardware infrastructure</CardDescription>
          </CardHeader>
          <CardContent>
            <p>
              The platform runs completely serverless, using microservices to ensure cost efficiency even at small
              scale. Lambda functions handle all backend logic, with DynamoDB for data storage.
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/architecture">
              <Button variant="outline">Learn More</Button>
            </Link>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Easy Installation</CardTitle>
            <CardDescription>Set up your blog in minutes</CardDescription>
          </CardHeader>
          <CardContent>
            <p>
              The platform comes with installation scripts that handle all AWS resource creation, including IAM roles,
              Lambda functions, API Gateway endpoints, and CloudFront distribution.
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/installation">
              <Button variant="outline">Installation Guide</Button>
            </Link>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Content Management</CardTitle>
            <CardDescription>Simple and powerful admin interface</CardDescription>
          </CardHeader>
          <CardContent>
            <p>
              Create, edit, and publish blog posts with a clean admin interface. The platform supports categories,
              featured images, and markdown content.
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/features">
              <Button variant="outline">View Features</Button>
            </Link>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>AWS Integration</CardTitle>
            <CardDescription>Leverages multiple AWS services</CardDescription>
          </CardHeader>
          <CardContent>
            <p>
              The platform integrates with API Gateway, Lambda, DynamoDB, S3, CloudFront, and SES to provide a complete
              blogging solution with minimal maintenance.
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/aws-services">
              <Button variant="outline">AWS Services</Button>
            </Link>
          </CardFooter>
        </Card>
      </div>

      <div className="mt-12 text-center">
        <Link href="/get-started">
          <Button size="lg">Get Started</Button>
        </Link>
      </div>
    </div>
  )
}
