import { Card, CardContent } from "@/components/ui/card"

export default function AWSServices() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-8">AWS Services Used</h1>

      <div className="mb-8">
        <p className="text-lg mb-4">
          The Lambda Blog Platform leverages several AWS services to create a completely serverless architecture.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        <Card>
          <CardContent className="pt-6">
            <h2 className="text-2xl font-bold mb-2">AWS Lambda</h2>
            <p className="mb-4">Serverless compute service that runs your code in response to events.</p>
            <h3 className="text-lg font-semibold mb-2">How we use it:</h3>
            <ul className="list-disc pl-6">
              <li>Serving blog posts and pages</li>
              <li>Processing form submissions</li>
              <li>Handling admin operations</li>
              <li>Image processing and optimization</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <h2 className="text-2xl font-bold mb-2">API Gateway</h2>
            <p className="mb-4">Create, publish, maintain, monitor, and secure APIs at any scale.</p>
            <h3 className="text-lg font-semibold mb-2">How we use it:</h3>
            <ul className="list-disc pl-6">
              <li>Routing HTTP requests to Lambda functions</li>
              <li>Authentication and authorization</li>
              <li>Request validation</li>
              <li>API versioning</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <h2 className="text-2xl font-bold mb-2">DynamoDB</h2>
            <p className="mb-4">Fully managed NoSQL database service for any scale.</p>
            <h3 className="text-lg font-semibold mb-2">How we use it:</h3>
            <ul className="list-disc pl-6">
              <li>Storing post metadata</li>
              <li>Managing categories and tags</li>
              <li>Storing configuration settings</li>
              <li>User management</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <h2 className="text-2xl font-bold mb-2">S3</h2>
            <p className="mb-4">
              Object storage service offering industry-leading scalability, availability, security, and performance.
            </p>
            <h3 className="text-lg font-semibold mb-2">How we use it:</h3>
            <ul className="list-disc pl-6">
              <li>Storing static assets (HTML, CSS, JS)</li>
              <li>Hosting blog post content</li>
              <li>Image and media storage</li>
              <li>Backup and archiving</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <h2 className="text-2xl font-bold mb-2">CloudFront</h2>
            <p className="mb-4">Fast content delivery network (CDN) service.</p>
            <h3 className="text-lg font-semibold mb-2">How we use it:</h3>
            <ul className="list-disc pl-6">
              <li>Global content delivery</li>
              <li>HTTPS support with custom domains</li>
              <li>Caching for improved performance</li>
              <li>Protection against DDoS attacks</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <h2 className="text-2xl font-bold mb-2">SES</h2>
            <p className="mb-4">Flexible, affordable email service.</p>
            <h3 className="text-lg font-semibold mb-2">How we use it:</h3>
            <ul className="list-disc pl-6">
              <li>Contact form submissions</li>
              <li>Notification emails</li>
              <li>Newsletter distribution</li>
              <li>Admin alerts</li>
            </ul>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="pt-6">
          <h2 className="text-2xl font-bold mb-4">Additional AWS Services</h2>
          <ul className="list-disc pl-6 grid grid-cols-1 md:grid-cols-2 gap-4">
            <li>
              <strong>IAM</strong> - Identity and Access Management for secure resource access
            </li>
            <li>
              <strong>Route53</strong> - Domain name system (DNS) web service
            </li>
            <li>
              <strong>ACM</strong> - AWS Certificate Manager for SSL/TLS certificates
            </li>
            <li>
              <strong>CloudWatch</strong> - Monitoring and observability service
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}
