import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function Installation() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-8">Installation Guide</h1>

      <div className="mb-8">
        <p className="text-lg mb-4">Follow these steps to install the Lambda Blog Platform on your AWS account.</p>
      </div>

      <Tabs defaultValue="standard" className="mb-8">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="standard">Standard Installation</TabsTrigger>
          <TabsTrigger value="advanced">Advanced Installation</TabsTrigger>
        </TabsList>
        <TabsContent value="standard">
          <Card>
            <CardContent className="pt-6">
              <h2 className="text-2xl font-bold mb-4">Prerequisites</h2>
              <ul className="list-disc pl-6 space-y-2 mb-6">
                <li>An AWS account</li>
                <li>A domain/subdomain set up in Route53</li>
                <li>An email address for certificate validation</li>
                <li>A certificate in AWS ACM (in the us-east-1 region)</li>
              </ul>

              <h2 className="text-2xl font-bold mb-4">Installation Steps</h2>
              <ol className="list-decimal pl-6 space-y-4">
                <li>
                  <p className="font-semibold">Download and prepare the project</p>
                  <pre className="bg-muted p-2 rounded-md text-sm mt-2">
                    git clone https://github.com/yourusername/lambda-blog-platform.git cd lambda-blog-platform npm
                    install
                  </pre>
                </li>
                <li>
                  <p className="font-semibold">Create a new IAM user</p>
                  <ul className="list-disc pl-6 mt-2">
                    <li>Go to IAM in AWS Console</li>
                    <li>Create a new user with Programmatic access</li>
                    <li>Download the credentials CSV file and save it in the project folder</li>
                  </ul>
                </li>
                <li>
                  <p className="font-semibold">Add permissions to the user</p>
                  <ul className="list-disc pl-6 mt-2">
                    <li>Add an inline policy with the permissions shown in the README</li>
                  </ul>
                </li>
                <li>
                  <p className="font-semibold">Run the installation script</p>
                  <pre className="bg-muted p-2 rounded-md text-sm mt-2">node install.js</pre>
                </li>
                <li>
                  <p className="font-semibold">Follow the wizard prompts</p>
                  <ul className="list-disc pl-6 mt-2">
                    <li>Enter installation prefix</li>
                    <li>Select AWS region</li>
                    <li>Select hosted zone</li>
                    <li>Enter domain/subdomain</li>
                    <li>Select certificate</li>
                    <li>Configure admin password and other settings</li>
                  </ul>
                </li>
                <li>
                  <p className="font-semibold">Wait for CloudFront distribution</p>
                  <p className="mt-2">This typically takes around 15 minutes to propagate.</p>
                </li>
              </ol>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="advanced">
          <Card>
            <CardContent className="pt-6">
              <h2 className="text-2xl font-bold mb-4">Advanced Installation</h2>
              <p className="mb-4">
                For more control over the installation process, you can use the advanced installation method.
              </p>

              <ol className="list-decimal pl-6 space-y-4">
                <li>
                  <p className="font-semibold">Prepare configuration file</p>
                  <pre className="bg-muted p-2 rounded-md text-sm mt-2">
                    cp install/install_config_template.js install_config.js
                  </pre>
                </li>
                <li>
                  <p className="font-semibold">Edit the configuration file</p>
                  <p className="mt-2">Modify install_config.js with your specific settings:</p>
                  <ul className="list-disc pl-6 mt-2">
                    <li>AWS credentials path</li>
                    <li>User name</li>
                    <li>Role name and policy names</li>
                    <li>Lambda function prefix</li>
                    <li>Domain name and hosted zone ID</li>
                    <li>CloudFront certificate ARN</li>
                    <li>Admin password and other settings</li>
                  </ul>
                </li>
                <li>
                  <p className="font-semibold">Run the advanced installation script</p>
                  <pre className="bg-muted p-2 rounded-md text-sm mt-2">node install_advanced.js</pre>
                </li>
                <li>
                  <p className="font-semibold">Run tests</p>
                  <pre className="bg-muted p-2 rounded-md text-sm mt-2">node run_tests.js</pre>
                </li>
              </ol>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card className="mb-8">
        <CardContent className="pt-6">
          <h2 className="text-2xl font-bold mb-4">Post-Installation</h2>
          <p className="mb-4">After installation is complete:</p>
          <ol className="list-decimal pl-6 space-y-2">
            <li>Access your blog at your configured domain</li>
            <li>
              Log in to the admin interface at yourdomain.com/admin using the password you set during installation
            </li>
            <li>Create your first blog post</li>
            <li>Configure additional settings in the admin panel</li>
          </ol>
        </CardContent>
      </Card>

      <div className="text-center mt-12">
        <Link href="/features">
          <Button>Explore Features</Button>
        </Link>
      </div>
    </div>
  )
}
