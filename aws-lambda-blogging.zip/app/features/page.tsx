import { Card, CardContent } from "@/components/ui/card"

export default function Features() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-8">Platform Features</h1>

      <div className="mb-8">
        <p className="text-lg mb-4">
          The Lambda Blog Platform comes with a rich set of features for both bloggers and developers.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
        <Card>
          <CardContent className="pt-6">
            <h2 className="text-xl font-bold mb-2">Content Management</h2>
            <ul className="list-disc pl-6">
              <li>Rich text editor</li>
              <li>Markdown support</li>
              <li>Image uploads</li>
              <li>Categories and tags</li>
              <li>Draft and publish workflow</li>
              <li>Scheduled publishing</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <h2 className="text-xl font-bold mb-2">Performance</h2>
            <ul className="list-disc pl-6">
              <li>Global CDN via CloudFront</li>
              <li>Optimized image delivery</li>
              <li>Serverless architecture</li>
              <li>Automatic scaling</li>
              <li>Low latency</li>
              <li>High availability</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <h2 className="text-xl font-bold mb-2">Security</h2>
            <ul className="list-disc pl-6">
              <li>HTTPS by default</li>
              <li>JWT authentication</li>
              <li>Secure admin access</li>
              <li>DDoS protection</li>
              <li>Input validation</li>
              <li>AWS IAM security</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <h2 className="text-xl font-bold mb-2">Customization</h2>
            <ul className="list-disc pl-6">
              <li>Templating system</li>
              <li>Custom CSS</li>
              <li>Theme support</li>
              <li>Layout options</li>
              <li>Widget areas</li>
              <li>Custom pages</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <h2 className="text-xl font-bold mb-2">Integrations</h2>
            <ul className="list-disc pl-6">
              <li>Disqus comments</li>
              <li>Social media sharing</li>
              <li>Google Analytics</li>
              <li>Email newsletters</li>
              <li>Contact forms</li>
              <li>ReCAPTCHA</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <h2 className="text-xl font-bold mb-2">Developer Features</h2>
            <ul className="list-disc pl-6">
              <li>API-first architecture</li>
              <li>Extensible Lambda functions</li>
              <li>Custom endpoints</li>
              <li>Webhook support</li>
              <li>Automated deployment</li>
              <li>Testing framework</li>
            </ul>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="pt-6">
          <h2 className="text-2xl font-bold mb-4">Admin Interface</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-2">Dashboard</h3>
              <ul className="list-disc pl-6 mb-4">
                <li>Overview of blog statistics</li>
                <li>Recent posts and comments</li>
                <li>Quick actions</li>
                <li>System status</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2">Post Editor</h3>
              <ul className="list-disc pl-6 mb-4">
                <li>WYSIWYG editing</li>
                <li>Media library</li>
                <li>SEO optimization tools</li>
                <li>Preview functionality</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2">Settings</h3>
              <ul className="list-disc pl-6 mb-4">
                <li>Site configuration</li>
                <li>Theme customization</li>
                <li>User management</li>
                <li>Integration settings</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2">Analytics</h3>
              <ul className="list-disc pl-6 mb-4">
                <li>Visitor statistics</li>
                <li>Popular content</li>
                <li>Traffic sources</li>
                <li>Engagement metrics</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
