import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export default function Architecture() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-8">Architecture Overview</h1>

      <div className="mb-8">
        <p className="text-lg mb-4">
          The Lambda Blog Platform uses a completely serverless architecture, leveraging multiple AWS services to create
          a scalable, maintainable blogging platform.
        </p>
      </div>

      <Card className="mb-8">
        <CardContent className="pt-6">
          <h2 className="text-2xl font-bold mb-4">Architecture Diagram</h2>
          <div className="p-4 border rounded-md bg-muted">
            <pre className="whitespace-pre-wrap">
              {`
Client -> CloudFront -> S3 (Static Assets)
                     -> API Gateway -> Lambda Functions -> DynamoDB
                                                        -> S3 (Articles)
                                                        -> SES (Email)
              `}
            </pre>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
        <Card>
          <CardContent className="pt-6">
            <h3 className="text-xl font-bold mb-2">Frontend</h3>
            <p>
              Static assets are stored in S3 and served through CloudFront for optimal performance. The admin interface
              is a single-page application that communicates with the backend via API Gateway.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <h3 className="text-xl font-bold mb-2">Backend</h3>
            <p>
              Lambda functions handle all backend logic, from serving blog posts to managing admin operations. These
              functions are triggered by API Gateway endpoints.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <h3 className="text-xl font-bold mb-2">Data Storage</h3>
            <p>
              DynamoDB tables store post metadata and configuration. Blog post content is stored in S3 for efficient
              retrieval and management.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <h3 className="text-xl font-bold mb-2">Content Delivery</h3>
            <p>
              CloudFront provides global content delivery with low latency. It serves both static assets and API
              responses through a single domain.
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-4">Lambda Functions</h2>
        <p className="mb-4">The platform uses several Lambda functions to handle different aspects of the blog:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li>
            <strong>get.js</strong> - Serves the main blog page
          </li>
          <li>
            <strong>get_post.js</strong> - Retrieves and serves individual blog posts
          </li>
          <li>
            <strong>get_posts_by_category.js</strong> - Filters posts by category
          </li>
          <li>
            <strong>about.js</strong> - Serves the about page
          </li>
          <li>
            <strong>contact.js</strong> - Handles contact form submissions
          </li>
          <li>Various admin functions for content management</li>
        </ul>
      </div>

      <div className="text-center mt-12">
        <Link href="/installation">
          <Button>Installation Guide</Button>
        </Link>
      </div>
    </div>
  )
}
