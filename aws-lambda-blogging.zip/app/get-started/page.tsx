import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { CheckCircle } from "lucide-react"

export default function GetStarted() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-8">Get Started</h1>

      <div className="mb-8">
        <p className="text-lg mb-4">Follow these steps to get your Lambda Blog Platform up and running.</p>
      </div>

      <div className="space-y-6 mb-12">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <div className="mt-1 text-green-500">
                <CheckCircle size={24} />
              </div>
              <div>
                <h2 className="text-xl font-bold mb-2">Step 1: Prerequisites</h2>
                <p className="mb-2">Make sure you have the following:</p>
                <ul className="list-disc pl-6 mb-4">
                  <li>An AWS account</li>
                  <li>A domain name configured in Route53</li>
                  <li>An SSL certificate in AWS Certificate Manager (us-east-1 region)</li>
                  <li>Node.js installed on your local machine</li>
                </ul>
                <Link href="/installation#prerequisites">
                  <Button variant="outline" size="sm">
                    View Prerequisites
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <div className="mt-1 text-green-500">
                <CheckCircle size={24} />
              </div>
              <div>
                <h2 className="text-xl font-bold mb-2">Step 2: Download and Install</h2>
                <p className="mb-2">Clone the repository and install dependencies:</p>
                <pre className="bg-muted p-2 rounded-md text-sm mb-4">
                  git clone https://github.com/yourusername/lambda-blog-platform.git cd lambda-blog-platform npm install
                </pre>
                <Link href="/installation">
                  <Button variant="outline" size="sm">
                    Installation Guide
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <div className="mt-1 text-green-500">
                <CheckCircle size={24} />
              </div>
              <div>
                <h2 className="text-xl font-bold mb-2">Step 3: Run Installation Script</h2>
                <p className="mb-2">Run the installation script and follow the prompts:</p>
                <pre className="bg-muted p-2 rounded-md text-sm mb-4">node install.js</pre>
                <p className="mb-4">The script will guide you through setting up all necessary AWS resources.</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <div className="mt-1 text-green-500">
                <CheckCircle size={24} />
              </div>
              <div>
                <h2 className="text-xl font-bold mb-2">Step 4: Access Your Blog</h2>
                <p className="mb-2">Once installation is complete (after CloudFront propagation, ~15 minutes):</p>
                <ul className="list-disc pl-6 mb-4">
                  <li>Visit your domain to see your blog</li>
                  <li>Access the admin panel at yourdomain.com/admin</li>
                  <li>Log in with the password you set during installation</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <div className="mt-1 text-green-500">
                <CheckCircle size={24} />
              </div>
              <div>
                <h2 className="text-xl font-bold mb-2">Step 5: Create Content</h2>
                <p className="mb-2">Start creating content for your blog:</p>
                <ul className="list-disc pl-6 mb-4">
                  <li>Create your first blog post</li>
                  <li>Set up categories and tags</li>
                  <li>Upload images and media</li>
                  <li>Configure your blog settings</li>
                </ul>
                <Link href="/features">
                  <Button variant="outline" size="sm">
                    Explore Features
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="pt-6">
          <h2 className="text-2xl font-bold mb-4">Next Steps</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold mb-2">Customize Your Blog</h3>
              <p>Personalize your blog's appearance and functionality:</p>
              <ul className="list-disc pl-6 mt-2">
                <li>Modify templates and styles</li>
                <li>Configure widgets and sidebars</li>
                <li>Set up integrations with third-party services</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2">Extend Functionality</h3>
              <p>Add new features to your blog:</p>
              <ul className="list-disc pl-6 mt-2">
                <li>Create custom Lambda functions</li>
                <li>Add API endpoints</li>
                <li>Implement additional AWS services</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="text-center mt-12">
        <Link href="/">
          <Button>Back to Home</Button>
        </Link>
      </div>
    </div>
  )
}
