import Link from "next/link"

export function Footer() {
  return (
    <footer className="border-t py-6 md:py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="font-bold mb-4">Lambda Blog Platform</h3>
            <p className="text-sm text-muted-foreground">
              A serverless blogging platform built with AWS Lambda, API Gateway, DynamoDB, S3, CloudFront, and SES.
            </p>
          </div>
          <div>
            <h3 className="font-bold mb-4">Documentation</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/architecture" className="hover:underline">
                  Architecture
                </Link>
              </li>
              <li>
                <Link href="/installation" className="hover:underline">
                  Installation
                </Link>
              </li>
              <li>
                <Link href="/features" className="hover:underline">
                  Features
                </Link>
              </li>
              <li>
                <Link href="/aws-services" className="hover:underline">
                  AWS Services
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold mb-4">Resources</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="#" className="hover:underline">
                  GitHub Repository
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:underline">
                  API Documentation
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:underline">
                  Troubleshooting
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:underline">
                  FAQ
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold mb-4">AWS Resources</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="https://aws.amazon.com/lambda/" className="hover:underline">
                  AWS Lambda
                </Link>
              </li>
              <li>
                <Link href="https://aws.amazon.com/api-gateway/" className="hover:underline">
                  API Gateway
                </Link>
              </li>
              <li>
                <Link href="https://aws.amazon.com/dynamodb/" className="hover:underline">
                  DynamoDB
                </Link>
              </li>
              <li>
                <Link href="https://aws.amazon.com/s3/" className="hover:underline">
                  S3
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-8 pt-6 border-t text-center text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} Lambda Blog Platform. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
