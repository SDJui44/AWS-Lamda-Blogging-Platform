import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Github } from "lucide-react"

export function Navbar() {
  return (
    <header className="border-b">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <Link href="/" className="font-bold text-xl">
          Lambda Blog Platform
        </Link>
        <nav className="hidden md:flex items-center gap-6">
          <Link href="/architecture" className="text-sm font-medium hover:underline">
            Architecture
          </Link>
          <Link href="/installation" className="text-sm font-medium hover:underline">
            Installation
          </Link>
          <Link href="/features" className="text-sm font-medium hover:underline">
            Features
          </Link>
          <Link href="/aws-services" className="text-sm font-medium hover:underline">
            AWS Services
          </Link>
        </nav>
        <div className="flex items-center gap-4">
          <Link href="https://github.com/yourusername/lambda-blog-platform" target="_blank">
            <Button variant="outline" size="icon">
              <Github className="h-4 w-4" />
              <span className="sr-only">GitHub</span>
            </Button>
          </Link>
          <Link href="/get-started">
            <Button>Get Started</Button>
          </Link>
        </div>
      </div>
    </header>
  )
}
